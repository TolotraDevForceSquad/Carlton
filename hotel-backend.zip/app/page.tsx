"use client"

import { PagesManager } from "../client/src/components/admin/PagesManager"

export default function SyntheticV0PageForDeployment() {
  return <PagesManager />
}