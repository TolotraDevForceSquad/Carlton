import type { Express } from "express"
import { createServer, type Server } from "http"
import { db } from "./db"
import {
  rooms,
  restaurants,
  events,
  bookings,
  contacts,
  pages,
  sections,
  gallery,
  insertRoomSchema,
  insertRestaurantSchema,
  insertEventSchema,
  insertBookingSchema,
  insertContactSchema,
  insertPageSchema,
  insertSectionSchema,
  insertGallerySchema,
} from "@shared/schema"
import { eq, desc, and, gte, lte } from "drizzle-orm"
import { uploadFile, deleteFile } from "./storage"

export function registerRoutes(app: Express): Server {
  // ============================================
  // PAGES & CMS ROUTES
  // ============================================

  // Get all pages
  app.get("/api/pages", async (req, res) => {
    try {
      const allPages = await db.select().from(pages).orderBy(pages.slug)
      res.json(allPages)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get page by slug with sections
  app.get("/api/pages/:slug", async (req, res) => {
    try {
      const [page] = await db.select().from(pages).where(eq(pages.slug, req.params.slug))

      if (!page) {
        return res.status(404).json({ message: "Page non trouvée" })
      }

      const pageSections = await db
        .select()
        .from(sections)
        .where(and(eq(sections.pageId, page.id), eq(sections.published, true)))
        .orderBy(sections.order)

      res.json({ ...page, sections: pageSections })
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create page
  app.post("/api/pages", async (req, res) => {
    try {
      const validatedData = insertPageSchema.parse(req.body)
      const [newPage] = await db.insert(pages).values(validatedData).returning()
      res.status(201).json(newPage)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update page
  app.put("/api/pages/:id", async (req, res) => {
    try {
      const validatedData = insertPageSchema.partial().parse(req.body)
      const [updatedPage] = await db
        .update(pages)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(pages.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedPage) {
        return res.status(404).json({ message: "Page non trouvée" })
      }

      res.json(updatedPage)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete page
  app.delete("/api/pages/:id", async (req, res) => {
    try {
      await db.delete(pages).where(eq(pages.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // SECTIONS ROUTES
  // ============================================

  // Get sections by page
  app.get("/api/sections/page/:pageId", async (req, res) => {
    try {
      const pageSections = await db
        .select()
        .from(sections)
        .where(eq(sections.pageId, Number.parseInt(req.params.pageId)))
        .orderBy(sections.order)
      res.json(pageSections)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create section
  app.post("/api/sections", async (req, res) => {
    try {
      const validatedData = insertSectionSchema.parse(req.body)
      const [newSection] = await db.insert(sections).values(validatedData).returning()
      res.status(201).json(newSection)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update section
  app.put("/api/sections/:id", async (req, res) => {
    try {
      const validatedData = insertSectionSchema.partial().parse(req.body)
      const [updatedSection] = await db
        .update(sections)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(sections.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedSection) {
        return res.status(404).json({ message: "Section non trouvée" })
      }

      res.json(updatedSection)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete section
  app.delete("/api/sections/:id", async (req, res) => {
    try {
      await db.delete(sections).where(eq(sections.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // ROOMS ROUTES
  // ============================================

  // Get all rooms
  app.get("/api/rooms", async (req, res) => {
    try {
      const allRooms = await db.select().from(rooms).orderBy(rooms.order)
      res.json(allRooms)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get room by ID
  app.get("/api/rooms/:id", async (req, res) => {
    try {
      const [room] = await db
        .select()
        .from(rooms)
        .where(eq(rooms.id, Number.parseInt(req.params.id)))

      if (!room) {
        return res.status(404).json({ message: "Chambre non trouvée" })
      }

      res.json(room)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create room
  app.post("/api/rooms", async (req, res) => {
    try {
      const validatedData = insertRoomSchema.parse(req.body)
      const [newRoom] = await db.insert(rooms).values(validatedData).returning()
      res.status(201).json(newRoom)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update room
  app.put("/api/rooms/:id", async (req, res) => {
    try {
      const validatedData = insertRoomSchema.partial().parse(req.body)
      const [updatedRoom] = await db
        .update(rooms)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(rooms.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedRoom) {
        return res.status(404).json({ message: "Chambre non trouvée" })
      }

      res.json(updatedRoom)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete room
  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      await db.delete(rooms).where(eq(rooms.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // RESTAURANTS ROUTES
  // ============================================

  // Get all restaurants
  app.get("/api/restaurants", async (req, res) => {
    try {
      const allRestaurants = await db.select().from(restaurants).orderBy(restaurants.order)
      res.json(allRestaurants)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get restaurant by ID
  app.get("/api/restaurants/:id", async (req, res) => {
    try {
      const [restaurant] = await db
        .select()
        .from(restaurants)
        .where(eq(restaurants.id, Number.parseInt(req.params.id)))

      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant non trouvé" })
      }

      res.json(restaurant)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create restaurant
  app.post("/api/restaurants", async (req, res) => {
    try {
      const validatedData = insertRestaurantSchema.parse(req.body)
      const [newRestaurant] = await db.insert(restaurants).values(validatedData).returning()
      res.status(201).json(newRestaurant)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update restaurant
  app.put("/api/restaurants/:id", async (req, res) => {
    try {
      const validatedData = insertRestaurantSchema.partial().parse(req.body)
      const [updatedRestaurant] = await db
        .update(restaurants)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(restaurants.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedRestaurant) {
        return res.status(404).json({ message: "Restaurant non trouvé" })
      }

      res.json(updatedRestaurant)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete restaurant
  app.delete("/api/restaurants/:id", async (req, res) => {
    try {
      await db.delete(restaurants).where(eq(restaurants.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // EVENTS ROUTES
  // ============================================

  // Get all events
  app.get("/api/events", async (req, res) => {
    try {
      const allEvents = await db.select().from(events).orderBy(events.order)
      res.json(allEvents)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get event by ID
  app.get("/api/events/:id", async (req, res) => {
    try {
      const [event] = await db
        .select()
        .from(events)
        .where(eq(events.id, Number.parseInt(req.params.id)))

      if (!event) {
        return res.status(404).json({ message: "Événement non trouvé" })
      }

      res.json(event)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create event
  app.post("/api/events", async (req, res) => {
    try {
      const validatedData = insertEventSchema.parse(req.body)
      const [newEvent] = await db.insert(events).values(validatedData).returning()
      res.status(201).json(newEvent)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update event
  app.put("/api/events/:id", async (req, res) => {
    try {
      const validatedData = insertEventSchema.partial().parse(req.body)
      const [updatedEvent] = await db
        .update(events)
        .set({ ...validatedData, updatedAt: new Date() })
        .where(eq(events.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedEvent) {
        return res.status(404).json({ message: "Événement non trouvé" })
      }

      res.json(updatedEvent)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete event
  app.delete("/api/events/:id", async (req, res) => {
    try {
      await db.delete(events).where(eq(events.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // BOOKINGS ROUTES
  // ============================================

  // Get all bookings
  app.get("/api/bookings", async (req, res) => {
    try {
      const allBookings = await db.select().from(bookings).orderBy(desc(bookings.createdAt))
      res.json(allBookings)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get booking by ID
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const [booking] = await db
        .select()
        .from(bookings)
        .where(eq(bookings.id, Number.parseInt(req.params.id)))

      if (!booking) {
        return res.status(404).json({ message: "Réservation non trouvée" })
      }

      res.json(booking)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Check room availability
  app.post("/api/bookings/check-availability", async (req, res) => {
    try {
      const { roomId, arrivalDate, departureDate } = req.body

      const conflictingBookings = await db
        .select()
        .from(bookings)
        .where(
          and(
            eq(bookings.roomId, roomId),
            eq(bookings.status, "confirmed"),
            // Check for date overlap
            gte(bookings.departureDate, new Date(arrivalDate)),
            lte(bookings.arrivalDate, new Date(departureDate)),
          ),
        )

      res.json({ available: conflictingBookings.length === 0 })
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body)
      const [newBooking] = await db.insert(bookings).values(validatedData).returning()
      res.status(201).json(newBooking)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update booking status
  app.patch("/api/bookings/:id/status", async (req, res) => {
    try {
      const { status } = req.body

      if (!["pending", "confirmed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Statut invalide" })
      }

      const [updatedBooking] = await db
        .update(bookings)
        .set({ status, updatedAt: new Date() })
        .where(eq(bookings.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedBooking) {
        return res.status(404).json({ message: "Réservation non trouvée" })
      }

      res.json(updatedBooking)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete booking
  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      await db.delete(bookings).where(eq(bookings.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // CONTACTS ROUTES
  // ============================================

  // Get all contacts
  app.get("/api/contacts", async (req, res) => {
    try {
      const allContacts = await db.select().from(contacts).orderBy(desc(contacts.createdAt))
      res.json(allContacts)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Get contact by ID
  app.get("/api/contacts/:id", async (req, res) => {
    try {
      const [contact] = await db
        .select()
        .from(contacts)
        .where(eq(contacts.id, Number.parseInt(req.params.id)))

      if (!contact) {
        return res.status(404).json({ message: "Contact non trouvé" })
      }

      res.json(contact)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create contact
  app.post("/api/contacts", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body)
      const [newContact] = await db.insert(contacts).values(validatedData).returning()
      res.status(201).json(newContact)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Update contact status
  app.patch("/api/contacts/:id/status", async (req, res) => {
    try {
      const { status } = req.body

      if (!["new", "read", "replied"].includes(status)) {
        return res.status(400).json({ message: "Statut invalide" })
      }

      const [updatedContact] = await db
        .update(contacts)
        .set({ status })
        .where(eq(contacts.id, Number.parseInt(req.params.id)))
        .returning()

      if (!updatedContact) {
        return res.status(404).json({ message: "Contact non trouvé" })
      }

      res.json(updatedContact)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete contact
  app.delete("/api/contacts/:id", async (req, res) => {
    try {
      await db.delete(contacts).where(eq(contacts.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // GALLERY ROUTES
  // ============================================

  // Get all gallery items
  app.get("/api/gallery", async (req, res) => {
    try {
      const { category } = req.query

      let query = db.select().from(gallery).where(eq(gallery.published, true))

      if (category && typeof category === "string") {
        query = db
          .select()
          .from(gallery)
          .where(and(eq(gallery.published, true), eq(gallery.category, category)))
      }

      const items = await query.orderBy(gallery.order)
      res.json(items)
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // Create gallery item
  app.post("/api/gallery", async (req, res) => {
    try {
      const validatedData = insertGallerySchema.parse(req.body)
      const [newItem] = await db.insert(gallery).values(validatedData).returning()
      res.status(201).json(newItem)
    } catch (error: any) {
      res.status(400).json({ message: error.message })
    }
  })

  // Delete gallery item
  app.delete("/api/gallery/:id", async (req, res) => {
    try {
      const [item] = await db
        .select()
        .from(gallery)
        .where(eq(gallery.id, Number.parseInt(req.params.id)))

      if (item?.image) {
        await deleteFile(item.image)
      }

      await db.delete(gallery).where(eq(gallery.id, Number.parseInt(req.params.id)))
      res.status(204).send()
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  // ============================================
  // FILE UPLOAD ROUTE
  // ============================================

  app.post("/api/upload", async (req, res) => {
    try {
      const { file, filename } = req.body

      if (!file || !filename) {
        return res.status(400).json({ message: "Fichier et nom de fichier requis" })
      }

      const url = await uploadFile(file, filename)
      res.json({ url })
    } catch (error: any) {
      res.status(500).json({ message: error.message })
    }
  })

  const httpServer = createServer(app)
  return httpServer
}
