import { put, del, list } from "@vercel/blob"

/**
 * Upload a file to Vercel Blob storage
 * @param file - Base64 encoded file or Buffer
 * @param filename - Name of the file
 * @returns URL of the uploaded file
 */
export async function uploadFile(file: string | Buffer, filename: string): Promise<string> {
  try {
    // Convert base64 to buffer if needed
    let buffer: Buffer

    if (typeof file === "string") {
      // Remove data URL prefix if present (e.g., "data:image/png;base64,")
      const base64Data = file.replace(/^data:image\/\w+;base64,/, "")
      buffer = Buffer.from(base64Data, "base64")
    } else {
      buffer = file
    }

    // Upload to Vercel Blob
    const blob = await put(filename, buffer, {
      access: "public",
      addRandomSuffix: true,
    })

    return blob.url
  } catch (error) {
    console.error("Error uploading file:", error)
    throw new Error("Failed to upload file")
  }
}

/**
 * Delete a file from Vercel Blob storage
 * @param url - URL of the file to delete
 */
export async function deleteFile(url: string): Promise<void> {
  try {
    await del(url)
  } catch (error) {
    console.error("Error deleting file:", error)
    throw new Error("Failed to delete file")
  }
}

/**
 * List all files in Vercel Blob storage
 * @param prefix - Optional prefix to filter files
 * @returns Array of blob objects
 */
export async function listFiles(prefix?: string) {
  try {
    const { blobs } = await list({
      prefix: prefix || "",
    })

    return blobs
  } catch (error) {
    console.error("Error listing files:", error)
    throw new Error("Failed to list files")
  }
}

/**
 * Get file URL by filename
 * @param filename - Name of the file
 * @returns URL of the file or null if not found
 */
export async function getFileUrl(filename: string): Promise<string | null> {
  try {
    const blobs = await listFiles(filename)

    if (blobs.length > 0) {
      return blobs[0].url
    }

    return null
  } catch (error) {
    console.error("Error getting file URL:", error)
    return null
  }
}
