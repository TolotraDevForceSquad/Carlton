import { pgTable, text, serial, integer, boolean, timestamp, json, varchar, decimal } from "drizzle-orm/pg-core"
import { createInsertSchema, createSelectSchema } from "drizzle-zod"
import { z } from "zod"

// ============================================
// PAGES & CMS TABLES
// ============================================

export const pages = pgTable("pages", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  heroImage: text("hero_image"),
  heroTitle: text("hero_title"),
  heroSubtitle: text("hero_subtitle"),
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  published: boolean("published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

export const sections = pgTable("sections", {
  id: serial("id").primaryKey(),
  pageId: integer("page_id").references(() => pages.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(), // 'room', 'restaurant', 'event', 'service', 'gallery'
  name: text("name").notNull(),
  subtitle: text("subtitle"),
  description: text("description"),
  image: text("image"),
  order: integer("order").default(0),

  // Room specific fields
  size: varchar("size", { length: 50 }),
  guests: varchar("guests", { length: 50 }),
  features: json("features").$type<string[]>(),
  amenities: json("amenities").$type<string[]>(),

  // Restaurant specific fields
  rating: varchar("rating", { length: 10 }),
  priceRange: varchar("price_range", { length: 20 }),
  hours: varchar("hours", { length: 100 }),
  capacity: varchar("capacity", { length: 100 }),
  dressCode: text("dress_code"),
  specialties: json("specialties").$type<string[]>(),

  // Event specific fields
  surface: varchar("surface", { length: 50 }),
  equipment: json("equipment").$type<string[]>(),

  // Common fields
  published: boolean("published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// ============================================
// ROOMS TABLE
// ============================================

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subtitle: text("subtitle"),
  description: text("description").notNull(),
  image: text("image"),
  size: varchar("size", { length: 50 }),
  guests: varchar("guests", { length: 50 }),
  price: decimal("price", { precision: 10, scale: 2 }),
  features: json("features").$type<string[]>(),
  amenities: json("amenities").$type<string[]>(),
  available: boolean("available").default(true),
  order: integer("order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// ============================================
// RESTAURANTS TABLE
// ============================================

export const restaurants = pgTable("restaurants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: varchar("type", { length: 100 }),
  description: text("description").notNull(),
  detailedDescription: text("detailed_description"),
  image: text("image"),
  rating: integer("rating").default(4),
  priceRange: varchar("price_range", { length: 20 }),
  hours: varchar("hours", { length: 100 }),
  capacity: varchar("capacity", { length: 100 }),
  reservationRequired: boolean("reservation_required").default(false),
  dressCode: text("dress_code"),
  specialties: json("specialties").$type<string[]>(),
  features: json("features").$type<string[]>(),
  order: integer("order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// ============================================
// EVENTS TABLE
// ============================================

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subtitle: text("subtitle"),
  description: text("description").notNull(),
  image: text("image"),
  capacity: varchar("capacity", { length: 100 }),
  duration: varchar("duration", { length: 100 }),
  surface: varchar("surface", { length: 50 }),
  equipment: json("equipment").$type<string[]>(),
  features: json("features").$type<string[]>(),
  order: integer("order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// ============================================
// BOOKINGS TABLE
// ============================================

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").references(() => rooms.id),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  arrivalDate: timestamp("arrival_date").notNull(),
  departureDate: timestamp("departure_date").notNull(),
  guests: integer("guests").notNull(),
  specialRequests: text("special_requests"),
  status: varchar("status", { length: 50 }).default("pending"), // pending, confirmed, cancelled
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// ============================================
// CONTACTS TABLE
// ============================================

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  arrivalDate: timestamp("arrival_date"),
  departureDate: timestamp("departure_date"),
  guests: varchar("guests", { length: 50 }),
  status: varchar("status", { length: 50 }).default("new"), // new, read, replied
  createdAt: timestamp("created_at").defaultNow(),
})

// ============================================
// GALLERY TABLE
// ============================================

export const gallery = pgTable("gallery", {
  id: serial("id").primaryKey(),
  title: text("title"),
  description: text("description"),
  image: text("image").notNull(),
  category: varchar("category", { length: 100 }), // 'room', 'restaurant', 'event', 'hotel', 'other'
  order: integer("order").default(0),
  published: boolean("published").default(true),
  createdAt: timestamp("created_at").defaultNow(),
})

// ============================================
// ZOD SCHEMAS FOR VALIDATION
// ============================================

// Pages schemas
export const insertPageSchema = createInsertSchema(pages)
export const selectPageSchema = createSelectSchema(pages)
export type InsertPage = z.infer<typeof insertPageSchema>
export type Page = z.infer<typeof selectPageSchema>

// Sections schemas
export const insertSectionSchema = createInsertSchema(sections)
export const selectSectionSchema = createSelectSchema(sections)
export type InsertSection = z.infer<typeof insertSectionSchema>
export type Section = z.infer<typeof selectSectionSchema>

// Rooms schemas
export const insertRoomSchema = createInsertSchema(rooms)
export const selectRoomSchema = createSelectSchema(rooms)
export type InsertRoom = z.infer<typeof insertRoomSchema>
export type Room = z.infer<typeof selectRoomSchema>

// Restaurants schemas
export const insertRestaurantSchema = createInsertSchema(restaurants)
export const selectRestaurantSchema = createSelectSchema(restaurants)
export type InsertRestaurant = z.infer<typeof insertRestaurantSchema>
export type Restaurant = z.infer<typeof selectRestaurantSchema>

// Events schemas
export const insertEventSchema = createInsertSchema(events)
export const selectEventSchema = createSelectSchema(events)
export type InsertEvent = z.infer<typeof insertEventSchema>
export type Event = z.infer<typeof selectEventSchema>

// Bookings schemas
export const insertBookingSchema = createInsertSchema(bookings, {
  email: z.string().email("Email invalide"),
  phone: z.string().min(8, "Le numéro de téléphone doit contenir au moins 8 chiffres"),
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères"),
  lastName: z.string().min(2, "Le nom doit contenir au moins 2 caractères"),
  guests: z.number().min(1, "Au moins 1 invité requis"),
})
export const selectBookingSchema = createSelectSchema(bookings)
export type InsertBooking = z.infer<typeof insertBookingSchema>
export type Booking = z.infer<typeof selectBookingSchema>

// Contacts schemas
export const insertContactSchema = createInsertSchema(contacts, {
  email: z.string().email("Email invalide"),
  phone: z.string().min(8, "Le numéro de téléphone doit contenir au moins 8 chiffres"),
  firstName: z.string().min(2, "Le prénom doit contenir au moins 2 caractères"),
  lastName: z.string().min(2, "Le nom doit contenir au moins 2 caractères"),
  message: z.string().min(10, "Le message doit contenir au moins 10 caractères"),
})
export const selectContactSchema = createSelectSchema(contacts)
export type InsertContact = z.infer<typeof insertContactSchema>
export type Contact = z.infer<typeof selectContactSchema>

// Gallery schemas
export const insertGallerySchema = createInsertSchema(gallery)
export const selectGallerySchema = createSelectSchema(gallery)
export type InsertGallery = z.infer<typeof insertGallerySchema>
export type Gallery = z.infer<typeof selectGallerySchema>
